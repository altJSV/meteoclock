Информация по установке библиотек: http://www.arduino.cc/en/Guide/Libraries
